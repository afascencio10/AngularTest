/**
 * Created by Felipe Estrada on 15/12/16.
 */

angular.module('app',
  ['ui.router',
    'app.controllers',
    'app.directives',
    'app.services',
    'chart.js'
  ])


