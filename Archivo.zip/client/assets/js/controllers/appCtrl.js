/**
 * Created by pipe on 18/12/16.
 */

angular.module('app.controllers', [])
