'use strict';

module.exports = function(Contratista) {

};
