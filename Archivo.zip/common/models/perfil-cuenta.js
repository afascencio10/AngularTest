'use strict';

module.exports = function(Perfilcuenta) {

};
