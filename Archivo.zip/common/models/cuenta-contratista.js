'use strict';

module.exports = function(Cuentacontratista) {

};
