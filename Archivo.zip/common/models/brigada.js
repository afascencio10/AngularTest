'use strict';

module.exports = function(Brigada) {

};
