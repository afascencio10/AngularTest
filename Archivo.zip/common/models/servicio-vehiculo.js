'use strict';

module.exports = function(Serviciovehiculo) {

};
