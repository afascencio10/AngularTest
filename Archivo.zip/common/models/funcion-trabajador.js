'use strict';

module.exports = function(Funciontrabajador) {

};
