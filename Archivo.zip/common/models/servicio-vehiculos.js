'use strict';

module.exports = function(Serviciovehiculos) {

};
