'use strict';

module.exports = function(Funcion) {

};
