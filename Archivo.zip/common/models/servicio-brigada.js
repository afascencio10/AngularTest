'use strict';

module.exports = function(Serviciobrigada) {

};
