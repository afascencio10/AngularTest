'use strict';

module.exports = function(Ubicacionvehiculo) {

};
