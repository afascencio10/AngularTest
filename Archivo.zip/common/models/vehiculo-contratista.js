'use strict';

module.exports = function(Vehiculocontratista) {

};
