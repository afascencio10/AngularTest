'use strict';

module.exports = function(Perfil) {

};
