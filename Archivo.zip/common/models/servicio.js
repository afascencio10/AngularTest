'use strict';

module.exports = function(Servicio) {

};
