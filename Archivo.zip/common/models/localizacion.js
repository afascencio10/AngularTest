'use strict';

module.exports = function(Localizacion) {

};
