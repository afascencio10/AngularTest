'use strict';

module.exports = function(Contactocontratista) {

};
