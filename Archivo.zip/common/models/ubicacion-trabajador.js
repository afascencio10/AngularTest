'use strict';

module.exports = function(Ubicaciontrabajador) {

};
