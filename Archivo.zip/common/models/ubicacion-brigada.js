'use strict';

module.exports = function(Ubicacionbrigada) {

};
