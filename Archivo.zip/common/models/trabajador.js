'use strict';

module.exports = function(Trabajador) {

};
