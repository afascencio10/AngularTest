'use strict';

module.exports = function(Contacto) {

};
