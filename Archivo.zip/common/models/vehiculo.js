'use strict';

module.exports = function(Vehiculo) {

};
